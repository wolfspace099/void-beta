#include <Arduino.h>
#include "Page.h"
#include "Screen.h"
#include "Inputs.h"
#include "Globals.h"
#include "Helpers.h"

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

static void waitEncRelease() {
    uint32_t t = millis();
    while (digitalRead(PIN_ENC_SW) == LOW) {
        if (millis() - t > 700) break;
        delay(1);
    }
}

// Draw a small horizontal bar: lo=left edge PWM, hi=right edge PWM,
// mid=neutral tick, val=current PWM. Shows the full 1000-2000 range.
void CalibratePage::drawLiveBar(int x, int y, int w, int h,
                                uint16_t pwm,
                                uint16_t lo, uint16_t mid, uint16_t hi) {
    u8g2.drawFrame(x, y, w, h);
    // neutral tick
    int midX = x + map(mid, 1000, 2000, 0, w - 1);
    u8g2.drawVLine(midX, y, h);
    // fill from neutral to current value
    int curX = x + map(constrain(pwm, 1000, 2000), 1000, 2000, 0, w - 1);
    if (curX > midX)
        u8g2.drawBox(midX, y + 1, curX - midX, h - 2);
    else if (curX < midX)
        u8g2.drawBox(curX + 1, y + 1, midX - curX, h - 2);
}

// ---------------------------------------------------------------------------
// init
// ---------------------------------------------------------------------------
void CalibratePage::init() {
    state       = CAL_MENU;
    menuHovered = 0;
    encReady    = false;
    aReady      = false;
    getRotaryEncoderSpins(); // flush
}

// ---------------------------------------------------------------------------
// Menu sub-loop  (Throttle / Steer / Test)
// ---------------------------------------------------------------------------
void CalibratePage::loopMenu() {
    static const char* opts[] = { "Throttle", "Steer", "Test" };
    const int N = 3;

    int spins = getRotaryEncoderSpins();
    if (spins > 0) menuHovered = (menuHovered + 1) % N;
    if (spins < 0) menuHovered = (menuHovered - 1 + N) % N;

    drawPageHeader("< Home < Menu < ", "Calibrate");

    u8g2.setFont(FONT_TEXT);
    int baseY = 28;
    int rowH  = 14;
    for (int i = 0; i < N; i++) {
        int y = baseY + i * rowH;
        u8g2.drawStr(14, y, opts[i]);
        if (menuHovered == i) {
            int tw = u8g2.getStrWidth(opts[i]);
            u8g2.drawRFrame(10, y - 10, tw + 8, 13, 4);
        }
    }

    int encSw = getRotaryEncoderSwitchValue();
    if (encSw == UNPRESSED) encReady = true;
    if (encSw == PRESSED && encReady) {
        encReady = false;
        waitEncRelease();
        getRotaryEncoderSpins();
        if (menuHovered == 0) {
            // Throttle cal: step 1 = center
            tmpCtr = 0; tmpMin = 0; tmpMax = 0;
            state = CAL_THROTTLE_CTR;
        } else if (menuHovered == 1) {
            tmpCtr = 0; tmpMin = 0; tmpMax = 0;
            state = CAL_STEER_CTR;
        } else {
            state = CAL_TEST;
        }
    }
}

// ---------------------------------------------------------------------------
// Generic capture step
//   Shows raw ADC value live, press encoder to record into `target`.
// ---------------------------------------------------------------------------
void CalibratePage::loopCapture(const char* axis, const char* step,
                                const char* hint,
                                CalibState  next,
                                uint16_t&   target) {
    int pin = (axis[0] == 'T') ? PIN_THROTTLE : PIN_STEER;
    int raw = analogRead(pin);

    drawPageHeader("< Calibrate < ", axis);

    u8g2.setFont(FONT_TEXT);
    u8g2.drawStr(4, 24, step);

    u8g2.setFont(FONT_TEXT_MONOSPACE);
    char buf[24];
    snprintf(buf, sizeof(buf), "Raw: %4d", raw);
    u8g2.drawStr(4, 38, buf);

    // mini progress bar of raw ADC (0-4095)
    int barW = 120, barH = 5;
    int barX = 4, barY = 42;
    u8g2.drawFrame(barX, barY, barW, barH);
    int fill = map(raw, 0, 4095, 0, barW - 2);
    if (fill > 0) u8g2.drawBox(barX + 1, barY + 1, fill, barH - 2);

    u8g2.setFont(FONT_TINY_TEXT);
    u8g2.drawStr(4, 56, hint);
    u8g2.drawStr(4, 63, "Press ENC to record  A=cancel");

    int encSw = getRotaryEncoderSwitchValue();
    if (encSw == UNPRESSED) encReady = true;
    if (encSw == PRESSED && encReady) {
        encReady = false;
        target   = (uint16_t)raw;
        waitEncRelease();
        getRotaryEncoderSpins();
        state = next;
    }
}

// ---------------------------------------------------------------------------
// Done step – show captured values, save on confirm
// ---------------------------------------------------------------------------
void CalibratePage::loopDone(const char* axis, CalibState nextAxis) {
    bool isThrottle = (axis[0] == 'T');

    drawPageHeader("< Calibrate < ", axis);

    u8g2.setFont(FONT_TEXT);
    u8g2.drawStr(4, 22, "Calibration done!");

    char buf[32];
    u8g2.setFont(FONT_TEXT_MONOSPACE);
    snprintf(buf, sizeof(buf), "Min: %4d", tmpMin);   u8g2.drawStr(4, 34, buf);
    snprintf(buf, sizeof(buf), "Ctr: %4d", tmpCtr);   u8g2.drawStr(4, 43, buf);
    snprintf(buf, sizeof(buf), "Max: %4d", tmpMax);   u8g2.drawStr(4, 52, buf);

    u8g2.setFont(FONT_TINY_TEXT);
    u8g2.drawStr(4, 63, "ENC=Save  A=Discard");

    int encSw = getRotaryEncoderSwitchValue();
    if (encSw == UNPRESSED) encReady = true;
    if (encSw == PRESSED && encReady) {
        encReady = false;
        // Validate: need min < ctr < max
        if (tmpMin < tmpCtr && tmpCtr < tmpMax) {
            if (isThrottle) {
                throttleCalMin    = tmpMin;
                throttleCalCenter = tmpCtr;
                throttleCalMax    = tmpMax;
            } else {
                steerCalMin    = tmpMin;
                steerCalCenter = tmpCtr;
                steerCalMax    = tmpMax;
            }
            saveProfiles();
        }
        waitEncRelease();
        getRotaryEncoderSpins();
        // Go back to menu after saving
        state    = CAL_MENU;
        encReady = false;
    }
}

// ---------------------------------------------------------------------------
// Test / live readout view
// ---------------------------------------------------------------------------
void CalibratePage::loopTest() {
    uint16_t tRaw  = (uint16_t)analogRead(PIN_THROTTLE);
    uint16_t sRaw  = (uint16_t)analogRead(PIN_STEER);
    uint16_t tPwm  = getThrottlePWM();
    uint16_t sPwm  = getSteerPWM();

    DriveMode& m = driveModes[currentMode];

    drawPageHeader("< Calibrate < ", "Test");

    u8g2.setFont(FONT_TEXT_MONOSPACE);
    char buf[32];

    // --- Throttle row ---
    snprintf(buf, sizeof(buf), "T raw:%4d  %4d", tRaw, tPwm);
    u8g2.drawStr(4, 22, buf);
    drawLiveBar(4, 24, 120, 5, tPwm, m.minPWM, m.midPWM, m.maxPWM);

    // --- Steer row ---
    snprintf(buf, sizeof(buf), "S raw:%4d  %4d", sRaw, sPwm);
    u8g2.drawStr(4, 37, buf);
    drawLiveBar(4, 39, 120, 5, sPwm, 1200, 1700, 2200);

    // Mode + expected range reminder
    u8g2.setFont(FONT_TINY_TEXT);
    snprintf(buf, sizeof(buf), "Mode:%s  T:%d-%d-%d",
             driveModes[currentMode].name,
             m.minPWM, m.midPWM, m.maxPWM);
    u8g2.drawStr(4, 53, buf);
    snprintf(buf, sizeof(buf), "Steer:1200-1700-2200");
    u8g2.drawStr(4, 61, buf);
}

// ---------------------------------------------------------------------------
// Main loop dispatcher
// ---------------------------------------------------------------------------
void CalibratePage::loop() {
    // A button always goes back one level
    if (getButtonValue(BTN_A) == UNPRESSED) aReady = true;
    if (getButtonValue(BTN_A) == PRESSED && aReady) {
        aReady = false;
        if (state == CAL_MENU) {
            currentPage = menuPage;
            return;
        }
        // Any other state: back to menu
        state    = CAL_MENU;
        encReady = false;
        getRotaryEncoderSpins();
        return;
    }

    u8g2.clearBuffer();

    switch (state) {

        // ---- MENU ----
        case CAL_MENU:
            loopMenu();
            break;

        // ---- THROTTLE WIZARD ----
        case CAL_THROTTLE_CTR:
            loopCapture("Throttle", "1. Release throttle",
                        "Let stick rest at center",
                        CAL_THROTTLE_MIN, tmpCtr);
            break;
        case CAL_THROTTLE_MIN:
            loopCapture("Throttle", "2. Full reverse / min",
                        "Push stick to min position",
                        CAL_THROTTLE_MAX, tmpMin);
            break;
        case CAL_THROTTLE_MAX:
            loopCapture("Throttle", "3. Full forward / max",
                        "Push stick to max position",
                        CAL_THROTTLE_DONE, tmpMax);
            break;
        case CAL_THROTTLE_DONE:
            loopDone("Throttle", CAL_MENU);
            break;

        // ---- STEER WIZARD ----
        case CAL_STEER_CTR:
            loopCapture("Steer", "1. Center steer",
                        "Let stick rest at center",
                        CAL_STEER_MIN, tmpCtr);
            break;
        case CAL_STEER_MIN:
            loopCapture("Steer", "2. Full left / min",
                        "Push stick fully left",
                        CAL_STEER_MAX, tmpMin);
            break;
        case CAL_STEER_MAX:
            loopCapture("Steer", "3. Full right / max",
                        "Push stick fully right",
                        CAL_STEER_DONE, tmpMax);
            break;
        case CAL_STEER_DONE:
            loopDone("Steer", CAL_MENU);
            break;

        // ---- TEST VIEW ----
        case CAL_TEST:
            loopTest();
            break;
    }

    u8g2.sendBuffer();
}
